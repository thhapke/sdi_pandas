Use this operator to submit your model KPIs/Metrics to the ML Tracking API. The `metrics`  port accepts metrics as a JSON Object. Ensure that each name/value pair corresponds to a "Metric Name": "Metric Value" pair. Note that all values must be strings.


Note:
 - This operator will cause your graph to terminate if your metrics are not submitted successfully.
 - This operator requires your pipeline to have been created via MLSM.

As an example, see below for the expected JSON format for the `metrics` port. 

```
{"Accuracy": "0.88", "Specificity": "0.92"}
```

In this example, when you run your graph, "Accuracy" and "Specificity" values will be posted to 
the ML tracking API. The metrics will be associated with the "Runtime Handle" of the graph that produced them.

Input
-----
* **metrics** (type: message): Accepts a JSON Object with your metrics that the pipeline submits to the ML Tracking API.

Output
---
* **response** (type: message): Outputs a string response if your metrics have been submitted successfully.
