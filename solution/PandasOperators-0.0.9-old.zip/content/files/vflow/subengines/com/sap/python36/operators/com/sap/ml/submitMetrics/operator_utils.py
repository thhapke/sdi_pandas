import base64
import binascii
import json
import time


# Constants for error messages
ERROR_GETTING_VSYSTEM_TOKEN = "Failed to contact vSystem to get a token. "
ERROR_GETTING_SCENARIO_ID = "Failed to get the scenario ID of the pipeline. "
ERROR_SUBMITTING_METRICS = "Failed to submit metrics. "
ERROR_CONTACTING_ML_TRACKING_API = "Failed to contact the ml-tracking API. "
METRICS_IS_NOT_VALID_JSON = "Invalid format. The metrics must be a JSON object or a JSON-object formatted string. "
METRIC_VALUE_IS_NOT_STRING = 'Invalid format. The metric value must be of type \"string\".'


# Adds equal signs to the string until its length is divisible by 4, needed for base64 decoding
def b64pad(s):
    return s + '=' * (-len(s) % 4)


class JavaWebToken(object):
    """
    This class represents an OAuth token, and includes handy functions such as checking if the token has expired.
    """
    # Gets a token as a string and extracts the information
    def __init__(self, token_string):
        self.exp = None  # only here for autocomplete and pep8
        self.encoded = None

        try:
            # Remove 'Bearer' if exist
            self.encoded = token_string.strip().split()[-1].strip()

            # Split by dots, decode the middle part using base64, read as JSON, update self
            payload = self.encoded.split('.')[1]
            payload_decoded = base64.urlsafe_b64decode(b64pad(payload))
            content = json.loads(payload_decoded)
            self.__dict__.update(content)

        except (AttributeError, IndexError, binascii.Error, UnicodeDecodeError, json.decoder.JSONDecodeError):
            message = "Failed to parse the token {}".format(token_string)
            raise Exception(message)

    def get_encoded(self):
        return self.encoded

    def get_bearer(self):
        return 'Bearer ' + self.encoded

    def is_expired(self):
        if self.exp and time.time() < float(self.exp):
            return False
        return True
