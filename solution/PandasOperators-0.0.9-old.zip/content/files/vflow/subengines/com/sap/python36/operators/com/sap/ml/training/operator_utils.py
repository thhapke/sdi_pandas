import base64
import binascii
import json
import time
from collections import namedtuple
from datetime import datetime


# Adds equal signs to the string until its length is divisible by 4, needed for base64 decoding
def b64pad(s):
    return s + '=' * (-len(s) % 4)


class JavaWebToken(object):
    """
    This class represents an OAuth token, and includes handy functions such as checking if the token has expired.
    """
    # Gets a token as a string and extracts the information
    def __init__(self, token_string):
        self.exp = None  # only here for autocomplete and pep8
        self.encoded = None

        try:
            # Remove 'Bearer' if exist
            self.encoded = token_string.strip().split()[-1].strip()

            # Split by dots, decode the middle part using base64, read as JSON, update self
            payload = self.encoded.split('.')[1]
            payload_decoded = base64.urlsafe_b64decode(b64pad(payload))
            content = json.loads(payload_decoded)
            self.__dict__.update(content)

        except (AttributeError, IndexError, binascii.Error, UnicodeDecodeError, json.decoder.JSONDecodeError):
            message = "Failed to parse the token {}".format(token_string)
            raise Exception(message)

    def get_encoded(self):
        return self.encoded

    def get_bearer(self):
        return 'Bearer ' + self.encoded

    def is_expired(self):
        if self.exp and time.time() < float(self.exp):
            return False
        return True


def get_error_message_from_http_response(response_obj):
    try:
        response_json = response_obj.json()
        if 'error' in response_json:
            # V3 API error response
            error = response_json.get('error').get('message', "")
        elif 'message' in response_json:
            # V2 API error response
            error = response_json.get('message')
        else:
            error = response_obj.content
    except json.JSONDecodeError:
        error = response_obj.content
    return error


def parse_training_log_timestamp_in_millisecond_granularity(log_timestamp):
    datetime_upto_millisecond = log_timestamp[:26]
    datetime_obj = datetime.strptime(datetime_upto_millisecond, '%Y-%m-%dT%H:%M:%S.%f')
    return datetime_obj


DATA_LAKE_CONNECTION = namedtuple('DATA_LAKE_CONNECTION', ['internal_url', 'external_url', 'token'])


def create_dl_artifact_uri(dl_url, execution_id, op_id, artifact_name):
    return "{}/webhdfs/v1/worm/sap/di/ml/artifacts/executions/{}/{}_{}".format(
        dl_url, execution_id, op_id, artifact_name
    )


def create_artifact_spec(name, uri, type, token):
    return {
        "name": name,
        "type": type,
        "uri": uri,
        "accessToken": token
    }


def read_artifact_manifest(exec_id, op_id, artifact_name, dl_client) -> dict:
    manifest_path = "/worm/sap/di/ml/artifacts/executions/{}/manifest_{}_{}.json".format(
        exec_id, op_id, artifact_name
    )

    with dl_client.read(manifest_path, encoding='utf-8') as reader:
        manifest = json.load(reader)
        return manifest


TRAINING_SCRIPT_ARTIFACT = namedtuple('TRAINING_SCRIPT_ARTIFACT', ['name', 'path_in_dl', 'path_in_job_container'])
