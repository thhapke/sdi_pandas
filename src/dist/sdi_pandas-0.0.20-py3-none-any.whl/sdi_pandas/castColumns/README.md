# castColumns - build.lib.sdi_pandas.castColumns (Version: 0.0.17)

Casting the types of columns according to the mapping given.

## Inport

* **inDataFrameMsg** (Type: message.DataFrame) 

## outports

* **Info** (Type: string) 
* **outDataFrameMsg** (Type: message.DataFrame) 

## Config

