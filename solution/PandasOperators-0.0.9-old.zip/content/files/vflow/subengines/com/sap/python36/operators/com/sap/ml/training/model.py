import sapdi


data_artifact = sapdi.get_artifact("data")
data_path = data_artifact.get_path()


out_artifact = sapdi.create_artifact("model", file_type=sapdi.artifact.ArtifactFileType.ZIP, description="Best model ever", artifact_name="model")
model_path = out_artifact.get_path()


