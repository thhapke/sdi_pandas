# castDataFrame
Casting the types of columns according to the mapping given. 

## Input
* **inDataFrame**

## Output
* **outDataFrame**
* **Info**

## Config
* **castm** -string- List of cast mappinging. Example: 'price':float32, 'rank':uint8  

* **round** -boolean- when true the values are rounded before the type is casted 
