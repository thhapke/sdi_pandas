# toCSVDataFrame
Creates a csv-formatted data passed to outport as message with the csv-string as body. 

## Input
* **inDataFrame**

## Output
* **outCSVMsg** string formatted as csv. 
* **Info**

## Config
* **write_index** -boolean- When True the index is saved as well
* **separator** -string- separator of the csv data (default = ; )