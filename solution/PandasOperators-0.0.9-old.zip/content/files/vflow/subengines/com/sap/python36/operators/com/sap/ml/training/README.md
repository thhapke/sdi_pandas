# Training with MLF

Dispatches Machine Learning jobs for execution.
In case the job was scheduled as expected, logs are continuously sent to the outport.
If job ends with status SUCCEEDED, the output artifacts are stored on the data lake and registered.


## Configuration parameters
  * **Training Image** (type string): The docker image that you want to run, e.g. ```com.sap.mlf/tyom-tf-1.12.0-py36-cpu```
  * **Resource Plan** (type string): Resources that your job needs. Select from a list of available resource plans.
  * **Completion Time** (type string): The time you want to allocate to run the job. An example value is e.g. "2h".
  * **Python Major Version** (type integer): Define the major python version of your model script. Allowed values are *2* or *3*. If set to *3* the requirements are installed with pip3 and the script is run with python3 command.
  * **PIP Requirements** (type string): A comma separated list of pip dependencies of your model script e.g.
  ```tensorflow==1.4.0,PyYAML==3.09```
  * **Artifacts** (type list): Artifacts (e.g., datasets) used as an input. The name acts as an alias to retrieve the artifact from inside the training job script. Use a placeholder for the id to allow selection of the artifact to be used in the scenario manager ui. The placeholder has the form ```${ARTIFACT:MODEL:<MODDEL_NAME>}``` (for models), or ```${ARTIFACT:DATASET:<DATASET_NAME>}``` (for datasets). You need to replace the <MODEL_NAME>/<DATASET_NAME> with the to be filtered name.
  * **Environment Variables** (type list): Environment variables used in the training process. Use a JSON array notation of name, value objects. 
  * **Script Arguments** Arguments to be passed to your script. Use a JSON array notation of name, value objects. The script arguments defined in this section are passed as parameters to your model script e.g.  
  ```[{"name":"argument","value":"value"}] ```  
  is passed as  
  ```--argument=value```
  * **Script** (type string): This is the actual script which defines the machine learning model.
    An example can be found at

    https://github.com/tensorflow/models/blob/master/official/wide_deep/wide_deep.py
    
    Inside the script, the python module sapdi is provided to access input artifact and create output artifact. See the SDK documentation or the provided example for details.



Input
------------
  * **artifacts** (type message.artifact): An input port is added from the UI for each artifact you want to pass. The job is triggered once all ingoing artifacts are available. A message of type message.artifact is expected to have an artifact name and an id as its attributes. For example, ```{'Attributes': {'artifactID': '5438b78c-cbcc-4ac1-aacf-92e52755e9da', 'name': 'train'}, 'Body': ''} ```. The artifact can then be accessed in your training script using the sapdi python module.

Output
------------
  * **logs** (type string): The logs returned by the training process. Polling every 20 second. This port can be connected e.g. to a terminal. 
  * **artifacts** (type message.artifact): The user can add custom output ports from the UI. For every such port, an artifact can be created inside the training script using the sapdi python module. The artifact is send through the out port after completion of the job

<br>
<div class="footer">
   &copy; 2019 SAP SE or an SAP affiliate company. All rights reserved.
</div>
