"""
This module requires the pysix_subengine module from vflow to be included in your PYTHONPATH
"""
import base64
import json
import os
import urllib.request
from datetime import datetime
from urllib.error import URLError

from .operator_utils import JavaWebToken, ERROR_CONTACTING_ML_TRACKING_API, ERROR_GETTING_SCENARIO_ID, \
    ERROR_GETTING_VSYSTEM_TOKEN, ERROR_SUBMITTING_METRICS, METRICS_IS_NOT_VALID_JSON, METRIC_VALUE_IS_NOT_STRING
from pysix_subengine.base_operator import BaseOperator
from pysix_subengine.base_operator import PortInfo, OperatorInfo
from pysix_subengine.message import Message

vsystem_internal_url = 'http://vsystem-internal:8796'
vsystem_app_id = os.environ["VSYSTEM_APP_ID"]
vsystem_secret = os.environ["VSYSTEM_SECRET"]

class SubmitMetrics(BaseOperator):

    def __init__(self, inst_id, op_id):
        super(SubmitMetrics, self).__init__(inst_id=inst_id, op_id=op_id)
        self._set_port_callback('metrics', self._data_in)
        self.ml_api_url = vsystem_internal_url + u"/app/ml-api/api/v1"
        self.ml_tracking_url = vsystem_internal_url + u"/app/ml-tracking/api/v1"
        self.vsystem_token = None  # an instance of JavaWebToken

    def _init(self):
        self.pipeline_id = self._get_pipeline_id()

    def _get_operator_info(self):
        dollar_type = "http://sap.com/vflow/com.sap.ml.submitMetrics.schema.json#"
        return OperatorInfo("Submit Metrics",
                            inports=[PortInfo("metrics", required=True, type_="message")],
                            outports=[PortInfo("response", required=True, type_="message")],
                            iconsrc="icon.png",
                            dollar_type=dollar_type)

    def _data_in(self, data: Message):
        kpi_dict = self._parse_input_metrics(data.body)
        metrics_json = self._create_metrics_json(kpi_dict)
        response = self._http_post_metrics_to_tracking_api(metrics_json)

        if 'message' not in response or response['message'] != 'Metrics created':
            raise SubmitMetricsError(json.dumps(response))

        self._send_message('response', Message('Metrics created'))

    def _create_metrics_json(self, metrics_data: dict) -> dict:
        metrics = []
        for name, value in metrics_data.items():
            labels = {}
            metric_value = None
            
            # adds MLOperationsUIUnit label to each metric. A custom label of name "format" is accounted as MLOperationsUIUnit
            if isinstance(value, dict):
                try:
                    metric_value = value["value"]
                except KeyError:
                    self.logger.warning("Value key not foud for metric: {}".format(name))
                labels_spec = value.get("labels", {})
                if not isinstance(labels_spec, dict):
                    self.logger.warning("Labels must be of type \"dict\".")
                    labels_spec = {}
                if "format" not in labels_spec:
                    labels["MLOperationsUIUnit"] = "string"
                for label, value in labels_spec.items():
                    if label == "format":
                        label = "MLOperationsUIUnit"
                    labels[label] = value
            else:
                labels["MLOperationsUIUnit"] = "string"
                metric_value = value

            metrics.append({
                'name': name,
                'type': 'string',
                'category': 'kpi',
                'value': metric_value,
                'labels': labels
            })

        return {
            'scenarioId': self._get_scenario_id(),
            'pipelineId': self.pipeline_id,
            'executionId': self._graph_handle,
            'metrics': metrics,
            'timestamp': self._get_timestamp()
        }

    def _get_pipeline_id(self) -> str:
        pipeline_id_prefix = 'com.sap.dsp.'
        if not self._graph_name.startswith(pipeline_id_prefix):
            raise SubmitMetricsError("Unexpected graph name. Ensure that this pipeline was created via MLSM.")
        return self._graph_name[len(pipeline_id_prefix):]

    def _http_post_metrics_to_tracking_api(self, metrics: dict) -> dict:
        headers = {
            'Authorization': self._http_get_vsystem_token(),
            'Content-Type': 'application/json',
            'Origin': vsystem_internal_url,
            'X-Requested-With': 'Fetch'
        }

        url = "{}/metrics".format(self.ml_tracking_url)
        req = urllib.request.Request(url, data=json.dumps(metrics).encode(), headers=headers)

        try:
            with urllib.request.urlopen(req) as response:
                response_content = response.read()
        except URLError as err:
            raise SubmitMetricsError(ERROR_CONTACTING_ML_TRACKING_API + str(err))

        return json.loads(response_content)

    def _http_get_vsystem_token(self):
        # Use the cached vSystem token
        if self.vsystem_token and not self.vsystem_token.is_expired():
            return self.vsystem_token.get_bearer()

        # Obtain a new vSystem token
        user_pass = vsystem_app_id + ':' + vsystem_secret 
        base64string = base64.b64encode(user_pass.encode('ascii'))
        req = urllib.request.Request(vsystem_internal_url + '/token/v2')
        req.add_header("Authorization", "Basic %s" % base64string.decode('ascii'))

        try:
            with urllib.request.urlopen(req) as response:
                header = response.getheader('Set-Cookie')
        except URLError as err:
            raise SubmitMetricsError(ERROR_GETTING_VSYSTEM_TOKEN + str(err))

        token = header[header.find('Authorization="') + len('Authorization="'):]
        # Update the cached token
        self.vsystem_token = JavaWebToken(token[:token.find('"')])
        return self.vsystem_token.get_bearer()

    def _get_scenario_id(self):
        headers = {
            'Authorization': self._http_get_vsystem_token(),
            'Content-Type': 'application/json',
        }
        url = "{}/pipelines/{}".format(self.ml_api_url, self.pipeline_id)
        req = urllib.request.Request(url, headers=headers)

        try:
            with urllib.request.urlopen(req) as response:
                response_content = response.read()
                if response.status == 200:
                    response_json = json.loads(response_content)
                    return response_json.get("scenarioId")
                else:
                    error = "Code: {}. Message: {}".format(response.status, response_content)
                    raise SubmitMetricsError(ERROR_GETTING_SCENARIO_ID + error)
        except URLError as err:
            raise SubmitMetricsError(ERROR_GETTING_SCENARIO_ID + str(err))
        except SubmitMetricsError:
            raise

    @staticmethod
    def _parse_input_metrics(metrics) -> dict:
        if isinstance(metrics, str):
            try:
                metrics = json.loads(metrics)
            except ValueError:
                raise SubmitMetricsError(METRICS_IS_NOT_VALID_JSON)

        if not isinstance(metrics, dict):
            raise SubmitMetricsError(METRICS_IS_NOT_VALID_JSON)

        return metrics

    @staticmethod
    def _get_timestamp():
        return datetime.now().strftime('%Y-%m-%dT%H:%M:%SZ')


class SubmitMetricsError(Exception):
    def __init__(self, message):
        super().__init__(ERROR_SUBMITTING_METRICS + str(message))
