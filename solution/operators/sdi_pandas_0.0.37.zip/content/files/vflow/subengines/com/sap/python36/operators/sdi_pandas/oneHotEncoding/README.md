# One Hot Encoding - sdi_pandas.oneHotEncoding (Version: 0.0.17)

Transforms string(object) columns to categoricals by using 'pandas.get_dummies()

## Inport

* **input** (Type: message.DataFrame) 

## outports

* **log** (Type: string) 
* **output** (Type: message.DataFrame) 

## Config

* **training_cols** - Training Columns (Type: string) Training Columns


# Tags
pandas : 

# References
[pandas doc: get_dummies](https://pandas.pydata.org/pandas-docs/stable/reference/api/pandas.get_dummies.html)

