# Python standard library imports
import json
import os
import uuid
import threading
import types
import time
from pathlib import Path
from shlex import quote

# third party imports
import requests
from hdfs import InsecureClient, HdfsError
from minio import Minio
from minio.error import ResponseError

# local application/library specific imports
from .operator_utils import create_artifact_spec, create_dl_artifact_uri, DATA_LAKE_CONNECTION, \
    get_error_message_from_http_response, JavaWebToken, parse_training_log_timestamp_in_millisecond_granularity, \
    read_artifact_manifest, TRAINING_SCRIPT_ARTIFACT
from pysix_subengine.base_pyextension_operator import BasePyExtensionOperator
from pysix_subengine.base_operator import PortInfo, OperatorInfo
from pysix_subengine.message import Message

vsystem_app_id = os.environ["VSYSTEM_APP_ID"]
vsystem_secret = os.environ["VSYSTEM_SECRET"]


class Training(BasePyExtensionOperator):

    def __init__(self, inst_id, op_id):
        super(Training, self).__init__(inst_id=inst_id, op_id=op_id)
        # Set default config properties
        self.config.image = u"com.sap.mlf/tyom-tf-1.12.0-py36-cpu"
        self.config.env = []
        self.config.resourcePlan = u"basic"
        self.config.completionTime = u"1h"
        self.config.pythonMajorVersion = u"3"
        self.config.requirements = u""
        self.config.artifacts = []
        self.config.scriptArguments = []
        # Read in model script
        self.config.script = u"file://model.py"
        self.config.scripts_folder = None

        self.operator_id = inst_id
        self.artifact_inports = []
        self.artifact_outports = []

        self.vsystem_internal_url = u"http://vsystem-internal:8796"
        self.vsystem_token = None  # an instance of operator_utils.JavaWebToken

        self.ml_api_url = self.vsystem_internal_url + u"/app/ml-api/api/v1"
        self.connection_manager_url = self.vsystem_internal_url + u"/app/datahub-app-connection"

        self.mlf_token = None  # an instance of operator_utils.JavaWebToken
        self.mlf_training_api_url = u""
        self.mlf_client_id = u""
        self.mlf_client_secret = u""
        self.mlf_authentication_url = u""
        self.endpoint = u""
        self.access_key = u""
        self.secret_key = u""
        self.previous_log_timestamp = None  # an instance of datetime.datetime
        self.previous_log_query_timestamp = ""

        self.output_artifacts_config = {}

        # Data lake related
        self.ca_cert = '/vrep/ca/ca.crt'
        self.sap_dl_connection_id = 'DI_DATA_LAKE'
        self.sap_dl_user = 'sdlclient'
        self.poll_job_logs = None
        self.log_polling_stopped = False

    def _init(self):
        self._validate_configuration()
        self._collect_ports()

    def _validate_configuration(self):
        """
        Validate some configurations of the training operator
        """
        # Validate the python version
        if str(self.config.pythonMajorVersion) not in ["2", "3"]:
            message = u"Unsupported python version {}. Only 2 or 3 are allowed".format(self.config.pythonMajorVersion)
            raise Exception(message)

        # Validate the training scripts
        operator_dir = Path(self._subengine_root, self.__class__.__module__.replace(".", "/")).resolve().parent

        if self.config.scripts_folder:
            # Normalize the script folder path to convert relative path to absolute path
            script_folder = Path(operator_dir, self.config.scripts_folder)
            if not script_folder.exists():
                raise Exception("Script folder {} does not exist.".format(self.config.scripts_folder))

            if not self.config.script.startswith(u"file://"):
                message = "Invalid configuration of 'script'. It must be a file path when 'scripts_folder' is used."
                raise Exception(message)

            # Check if the specified script path is within the specified script folder and if yes, derive the path
            # of the script relative to the script folder
            script_path = Path(operator_dir, self.config.script[7:])
            try:
                self.config.script = script_path.relative_to(script_folder)
            except ValueError:
                raise Exception(
                    "Script {} is not in the script folder {}".format(self.config.script, self.config.scripts_folder)
                )
            self.config.scripts_folder = script_folder

        elif self.config.script.startswith(u"file://"):
            script_path = str(Path(operator_dir, self.config.script[7:]))
            try:
                with open(script_path, "r") as f:
                    self.config.script = f.read()
            except Exception as e:
                raise ValueError(u"Error while trying to read script in %s: %s" % (script_path, str(e)))

            if self.config.script == u"":
                raise ValueError(u"script cannot be empty")

    def _get_vsystem_token(self) -> JavaWebToken:
        """
        Get a token for talking to vSystem applications such as ML API and Connection Manager
        """
        # Use the cached vSystem token if it exists and has not expired
        if self.vsystem_token and not self.vsystem_token.is_expired():
            self.logger.debug("Use cached vSystem token")
            return self.vsystem_token

        # Obtain a new vSystem token if there is no cache yet or if the cached token has expired
        self.logger.debug("Obtain a new vSystem token.")
        url = self.vsystem_internal_url + u"/token/v2"

        try:
            response = requests.get(url, auth=(vsystem_app_id, vsystem_secret), verify=self.ca_cert)
        except requests.exceptions.RequestException as err:
            message = "GET request to vSystem token endpoint failed. Reason: {}".format(str(err))
            self.logger.fatal(message)
            raise Exception(message)

        if response.status_code == 200:
            r = response.json()
            access_token = r[u"access_token"]
            # Update the cached token
            self.vsystem_token = JavaWebToken(access_token)
            return self.vsystem_token
        else:
            error = get_error_message_from_http_response(response)
            message = u"Retrieving vSystem token failed with code {}. Error message: {}.".format(
                response.status_code, error)
            raise Exception(message)

    def _get_mlf_token(self) -> JavaWebToken:
        """
        Get a token for talking to ML Foundation
        """
        # Use the cached MLF token if it exists and has not expired
        if self.mlf_token and not self.mlf_token.is_expired():
            self.logger.debug("Use cached MLF token.")
            return self.mlf_token

        # Obtain a new MLF token if there is no cache yet or if the cached token has expired
        self.logger.debug("Obtain a new MLF token")
        token_url = u"{}/oauth/token?grant_type=client_credentials".format(self.mlf_authentication_url)
        try:
            response = requests.get(token_url, auth=(self.mlf_client_id, self.mlf_client_secret))
        except requests.exceptions.RequestException as err:
            message = "GET request to ML Foundation token endpoint failed. Reason: {}".format(str(err))
            self.logger.fatal(message)
            raise Exception(message)

        if response.status_code == 200:
            token_response = response.json()
            # Update the cached token
            self.mlf_token = JavaWebToken(token_response[u"access_token"])
            return self.mlf_token
        else:
            error = get_error_message_from_http_response(response)
            message = u"Retrieving access token for MLF failed with code {}. Error message: {}".format(
                response.status_code, error
            )
            raise Exception(message)

    @classmethod
    def _skip_connections_check(cls):
        return False

    def _get_mlf_connection_details(self):
        """
        Retrieve details for connecting to ML Foundation from the connection manager
        """
        headers = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'Fetch',
            'Authorization': self._get_vsystem_token().get_bearer()
        }

        try:
            url = "{}/connectionsFull/MLF_CONNECTION_ID?connectionTypes=MLCLUSTER".format(self.connection_manager_url)
            response = requests.get(url, headers=headers, verify=self.ca_cert)
        except requests.exceptions.RequestException as err:
            message = "Get MLF connection from Connection Manager failed. Reason: {}".format(str(err))
            self.logger.fatal(message)
            raise Exception(message)

        if response.status_code == 200:
            r = response.json()
            try:
                mlf_service_key = json.loads(r["contentData"]["serviceKey"])
                mlf_credentials = mlf_service_key["credentials"]
                self.mlf_client_id = mlf_credentials["clientid"]
                self.mlf_client_secret = mlf_credentials["clientsecret"]
                self.mlf_training_api_url = mlf_credentials["serviceurls"]["JOB_SUBMISSION_API_URL"]
                self.mlf_authentication_url = mlf_credentials["url"]
            except (json.JSONDecodeError, KeyError):
                raise Exception("Failed to extract MLF connection details from the response of the connection manager.")
        else:
            error = get_error_message_from_http_response(response)
            message = u"Retrieving connection details for MLF failed with code {}. Error message: {}".format(
                response.status_code, error
            )
            raise Exception(message)

    def _collect_ports(self):
        """
        collects user defined inports and outports
        """
        old_op_info = self._get_operator_info()

        old_outports_names = set()
        for port_info in old_op_info.outports:
            old_outports_names.add(port_info.name)

        for port, queue in self.outqs.items():
            if port not in old_outports_names:
                self.artifact_outports.append(port)

        old_inports_names = set()
        for port_info in old_op_info.inports:
            old_inports_names.add(port_info.name)

        for port, queue in self.inqs.items():
            if port not in old_inports_names:
                self.artifact_inports.append(port)

        if self.artifact_inports:
            # sets the artifact ports as required
            for port in self._final_operator_info.inports:
                if port.name in self.artifact_inports:
                    port.required = True
            # defines callback for each extra port
            argstr = ",".join(self.artifact_inports)
            exec("def mycallback(self, %s):\n\tself._collect_artifact(%s)" % (argstr, argstr), globals())
            self.mycallback = types.MethodType(mycallback, self)
            self._set_port_callback(self.artifact_inports, self.mycallback)

    def _get_operator_info(self):
        inports = []
        outports = [PortInfo(u"logs", required=True, type_=u"string")]
        return OperatorInfo(u"training",
                            inports=inports,
                            outports=outports,
                            iconsrc="Train.png",
                            dollar_type="http://sap.com/vflow/com.sap.ml.training.schema.json#",
                            tags={"minio": "3.0.3", "requests": "2.18.4", "hdfs": "2.5.0"},
                            enable_port_extension=True)

    def _fetch_training_log(self):
        """
        Fetch the latest log of the training job from MLF
        """
        headers = self._prepare_header_for_mlf_request()
        log_endpoint = u"{}/log".format(self.mlf_training_job_endpoint)
        params = {"$top": 200}
        if self.previous_log_query_timestamp:
            params["since"] = self.previous_log_query_timestamp

        try:
            response = requests.get(log_endpoint, headers=headers, params=params)
        except requests.exceptions.RequestException as err:
            message = "GET request to fetch logs of job {} failed. Error message: {}".format(self.jobID, str(err))
            self.logger.warning(message)
            raise Exception(message)

        if response.status_code == 200:
            logs = response.json()[u'logs']
            log_length = len(logs)

            check_duplication = True and self.previous_log_timestamp
            for index, element in enumerate(logs):
                log_timestamp = element[u'timestamp']
                datetime_obj = parse_training_log_timestamp_in_millisecond_granularity(log_timestamp)

                # Skipping logs that have been output
                if check_duplication:
                    if datetime_obj <= self.previous_log_timestamp:
                        continue
                    else:
                        check_duplication = False

                # Update the timestamp to be used in the next query for logs
                if index + 1 == log_length:
                    self.previous_log_timestamp = datetime_obj
                    self.previous_log_query_timestamp = "{}+00:00".format(log_timestamp[:19])

                log = u'{date} {time} \"{content}\"'.format(
                    date=log_timestamp[:10],
                    time=log_timestamp[11:19],
                    content=element[u'content']
                )
                self.logger.info("training log: " + log)
                self._send_message(u"logs", log)
        else:
            message = "Reading logs of training job failed with code {}. Error message: {}".format(
                response.status_code, get_error_message_from_http_response(response)
            )
            self.logger.warning(message)

    def _print_logs(self):
        if self.poll_job_logs is None:
            self.poll_job_logs = True
        elif not self.poll_job_logs:
            self.log_polling_stopped = True
            self.logger.debug("Polling of the job logs is stopped.")
            return
        threading.Timer(20.0, self._print_logs).start()
        self._fetch_training_log()

    def _delete_from_minio(self):
        minio_client = self._get_minio_client()
        work_dir = 'jobs/{}-{}'.format(self.operator_id, self.jobID)
        try:
            model_objects = minio_client.list_objects_v2('data', prefix=work_dir, recursive=True)
            for object in model_objects:
                minio_client.remove_object(
                    bucket_name='data',
                    object_name=object.object_name.encode('utf-8')
                )
        except ResponseError as err:
            message = "Failed to delete files in MLF with minio. Reason: {}".format(str(err))
            self.logger.warning(message)

    def _delete_training_scripts_in_data_lake(self):
        self.logger.debug("Deleting training script from Data Lake...")
        dl_conn, dl_client = self._get_data_lake_client()
        try:
            dl_client.delete(hdfs_path=self.dl_dir_for_scripts, recursive=True)
        except HdfsError as err:
            raise Exception("Failed to delete training scripts in Data Lake. Reason {}".format(str(err)))

    def _delete_training_job(self, is_poll_for_deletion=True):
        """
        Send deletion request for the current training job
        """
        # Stop the log polling thread if it has started
        if self.poll_job_logs is not None:
            self.poll_job_logs = False
            while not self.log_polling_stopped:
                time.sleep(2)

        # Fetch logs for one last time before sending the job deletion request
        self.logger.debug("Fetch logs before deleting the job %s", self.jobID)
        self._fetch_training_log()

        headers = self._prepare_header_for_mlf_request()
        try:
            response = requests.delete(self.mlf_training_job_endpoint, headers=headers)
            if response.status_code == 202:
                self.logger.info("Deletion request for job {} was accepted.".format(self.jobID))
            elif response.status_code == 404:
                self.logger.info("Training job {} was not found or already deleted.".format(self.jobID))
            else:
                message = "Deletion request for the training job {} failed with code {}. Error message: {}".format(
                    self.jobID, response.status_code, get_error_message_from_http_response(response)
                )
                self.logger.warning(message)
        except requests.exceptions.RequestException as err:
            self.logger.warning(err)
            message = "DELETE request for the training job {} failed. Error message: {}".format(self.jobID, str(err))
            raise Exception(message)

        self._delete_from_minio()
        self._delete_training_scripts_in_data_lake()

        if is_poll_for_deletion:
            # Check if the job is deleted by polling 404 for job status    
            self._poll_for_deletion()

    def _poll_for_deletion(self):
        """
        Polls until the job is deleted (404) or if deletion failed
        """
        t = threading.Timer(60.0, self._is_deletion_complete)
        t.start()
        job_status = self._is_deletion_complete()
        if job_status == 404 or job_status != 200:
            t.cancel()

    def _is_deletion_complete(self):
        """
        Checks status of job after deletion request.
        """
        headers = self._prepare_header_for_mlf_request()

        try:
            response = requests.get(self.mlf_training_job_endpoint, headers=headers)
            if response.status_code == 404:
                self.logger.info("Deletion of job {} successful".format(self.jobID))
            elif response.status_code != 200:
                message = "Deletion of training job {} failed with code {}. \
                Error message: {}".format(
                    self.jobID, response.status_code, get_error_message_from_http_response(response)
                )
                self.logger.warning(message)

            return response.status_code
        except requests.exceptions.RequestException as err:
            message = "GET status of training job {} after the DELETE request failed. Error message: {}".format(
                self.jobID, str(err)
            )
            self.logger.warning(message)
            raise Exception(message)
        except Exception as e:
            self._propagate_exception(e)

    def _send_artifacts(self, registered_artifacts: dict, job_status: dict):
        """
        For each registered output artifact, send a message to its corresponding outport
        """
        self.logger.debug("Publish registered artifacts")
        for artifact_name, artifact_id in registered_artifacts.items():
            headers = {
                "artifactID": artifact_id,
                "name": artifact_name,
                "job_status": job_status
            }
            message = {
                "Attributes": headers,
                "Body": ""
            }
            self._send_message(artifact_name, message)

    def _get_status(self):
        t = threading.Timer(60.0, self._get_status)
        t.start()
        headers = self._prepare_header_for_mlf_request()
        r = requests.get(self.mlf_training_job_endpoint, headers=headers)
        try:
            job_status = r.json()
            self.logger.debug(job_status)

            status = job_status[u'status'].upper()
            if status == u"SUCCEEDED":
                t.cancel()

                self.logger.debug("Training job succeeded. Proceeding to create output artifacts.")
                registered_artifacts = self._register_all_dl_output_artifacts()

                self.logger.info("Creation of artifacts succeeded. Proceeding to delete the training job ...")
                self._delete_training_job()
                self.logger.debug("Notify the successful completion of the training process.")

                # Send artifacts only after job logs are fetched and job is deleted, so that a graph terminator
                # put behind the outports cannot terminate the log fetching and job deletion before they finish.
                self._send_artifacts(registered_artifacts, job_status)

            elif status == u"FAILED":
                message = "Training failed. {}".format(job_status.get(u'message'))
                self._delete_training_job()
                raise Exception(message)

        except (ValueError, KeyError):
            self.logger.warning(u"Could not retrieve status of job %s. Response: %s", self.jobID, r.content)
        except Exception as e:
            self._propagate_exception(e)

    def _train(self, artifact_for_scripts: TRAINING_SCRIPT_ARTIFACT):
        headers, payload = self._prepare_request(artifact_for_scripts)

        req = requests.Request(u"POST", url=self.mlf_training_job_endpoint, headers=headers, data=payload)
        prepared = req.prepare()
        s = requests.Session()
        response = s.send(prepared)
        self.logger.info("After submitting job " + str(response.status_code))

        if response.status_code == 202:
            message = u'Job submitted successfully with UUID ' + self.jobID
            self.logger.info(message)
            self._send_message(u"logs", message)

            self._print_logs()
            self._get_status()
        else:
            message = u'Job was not submitted \n' + response.text
            self.logger.fatal(message)
            raise Exception(message)

    def _create_command(self, script_path_in_job_container: str):
        is_python2 = str(self.config.pythonMajorVersion) == "2"

        # Pip-install command
        pip_install_cmd = ""
        if self.config.requirements:
            requirements = [quote(pkg.strip()) for pkg in self.config.requirements.split(',') if pkg.strip()]
            pip = 'pip' if is_python2 else 'pip3'
            pip_install_cmd = "{} install {}".format(pip, " ".join(requirements))

        # Python-run command
        parameters = []
        for arg in self.config.scriptArguments:
            arg_str = u"--{}={}".format(arg["name"], arg["value"])
            parameters.append(arg_str)
        param = " ".join(parameters)

        python = "python" if is_python2 else "python3"
        python_cmd = "{} {} {}".format(python, script_path_in_job_container, param)

        command = "{} && {}".format(pip_install_cmd, python_cmd) if pip_install_cmd else python_cmd
        self.logger.info(u"The executable command is: %s", command)
        return command

    def _prepare_training_environment_variables(self):
        """
        Prepare the environment variables to be injected in the container of the training job at runtime
        """
        training_env = [{
            "name": "DI_SDK_RUNTIME_CONTEXT",  # To enable the SDK
            "value": "TRAINING_SERVICE_EXECUTION"
        }]

        # Union with user-specified environment variables
        for element in self.config.env:
            training_env.append(element)
        return training_env

    def _prepare_request(self, artifact_for_scripts: TRAINING_SCRIPT_ARTIFACT):
        """
        Prepare the job submission request to be sent to the MLF training service
        """
        headers = self._prepare_header_for_mlf_request()
        env = self._prepare_training_environment_variables()
        command = self._create_command(artifact_for_scripts.path_in_job_container)
        data = {
            u'job': {
                u'env': env,
                u'execution': {
                    u'command': command,
                    u'image': self.config.image,
                    u'resourcePlanId': self.config.resourcePlan,
                    u'completionTime': self.config.completionTime,
                },
                u'name': self.operator_id
            }
        }

        artifacts = self._prepare_training_artifacts(artifact_for_scripts)
        data['job']['artifacts'] = artifacts

        payload = json.dumps(data)
        return headers, payload

    def _get_artifact_by_id(self, artifact_id):
        """
        Query the ML API to get the metadata of a specific artifact
        """
        headers = {
            'Authorization': self._get_vsystem_token().get_bearer(),
            'Content-Type': 'application/json',
        }

        try:
            response = requests.get(u"{}/artifacts/{}".format(self.ml_api_url, artifact_id), headers=headers)
        except requests.exceptions.RequestException as err:
            self.logger.fatal(err)
            raise Exception("GET request to ML API /artifacts endpoint failed.")

        if response.status_code == 200:
            self.logger.debug(u"Retrieving metadata of artifact %s succeeded.", artifact_id)
            return response.json()
        else:
            error = get_error_message_from_http_response(response)
            message = u"Retrieving metadata of artifact {} failed with code {}. Error message: {}".format(
                artifact_id, response.status_code, error
            )
            raise Exception(message)

    def _register_artifact(self, artifact_name, artifact_kind, execution_id, uri, description=None):
        """
        Register an artifact via ML API.
        """
        request_body = {
            "name": artifact_name,
            "kind": artifact_kind,
            "uri": uri,
            "type": "EXECUTION",
            "executionId": execution_id
        }

        if description:
            request_body["description"] = description

        headers = {
            'Authorization': self._get_vsystem_token().get_bearer(),
            'Content-Type': 'application/json',
        }

        try:
            response = requests.post(u"{}/artifacts".format(self.ml_api_url), json=request_body, headers=headers)
        except requests.exceptions.RequestException as err:
            self.logger.fatal(err)
            raise Exception("POST request to ML API /artifacts endpoint failed.")

        if response.status_code == 201:
            response_json = response.json()
            artifact_id = response_json.get('id')

            message = u"Registering artifact for `{}` succeeded with id {}.".format(artifact_name, artifact_id)
            self.logger.info(message)

            return artifact_id
        else:
            error = get_error_message_from_http_response(response)
            message = u"Registering artifact for `{}` failed with code {}. Error message: {}.".format(
                artifact_name, response.status_code, error
            )
            raise Exception(message)

    def _parse_artifact_uri(self, artifact_uri):
        """
        Parse an artifact uri based on its protocol
        """
        dl_uri_prefix = "dh-dl://"
        if artifact_uri.startswith(dl_uri_prefix):
            # remove the connection id from the path
            uri_without_prefix = artifact_uri[len(dl_uri_prefix):]
            path_parts = Path(uri_without_prefix).parts
            connection_id = path_parts[0]
            path_in_dl = "/".join(path_parts[1:])
            return connection_id, path_in_dl

        # TODO: support other protocols
        message = u"Failed to parse artifact uri {}. Unsupported protocol.".format(artifact_uri)
        raise Exception(message)

    def _collect_artifact(self, *args):
        """
        Collects artifact from input ports
        """
        for i, data in enumerate(args):
            port_active = self.artifact_inports[i]
            artifact = {}
            if isinstance(data, dict):
                try:
                    artifact = data["Attributes"]
                except KeyError:
                    self.logger.fatal("Error on port %s :: Attributes is missing in the input message!", port_active)
            elif isinstance(data, Message):
                artifact = data.attributes
            elif isinstance(data, str):
                try:
                    data_json = json.loads(data)
                    artifact = data_json["Attributes"]
                except ValueError as err:
                    self.logger.fatal("Error on port %s :: input message is not a valid JSON! :: %s", port_active, err)
                except KeyError:
                    self.logger.fatal("Error on port %s :: Attributes is missing in the input message!", port_active)

            if not isinstance(artifact, dict):
                self.logger.fatal("Error on port %s :: Attributes is not a valid JSON!", port_active)
            if "artifactID" not in artifact:
                self.logger.fatal("Error on port %s :: Artifact id is missing!", port_active)

            self.config.artifacts.append({
                "artifactId": artifact["artifactID"],
                "name": port_active
            })

        self._upload_training_scripts()

    def _get_data_lake_connection_details(self, conn_id):
        """
        Retrieve details for connecting with Data Lake from the connection manager
        """
        headers = {
            'Content-Type': 'application/json',
            'X-Requested-With': 'Fetch',
            'Authorization': self._get_vsystem_token().get_bearer()
        }

        try:
            url = "{}/connectionsFull/{}?connectionTypes=SDL".format(self.connection_manager_url, conn_id)
            response = requests.get(url, headers=headers, verify=self.ca_cert)
        except requests.exceptions.RequestException as err:
            message = "Get Data Lake connection {} from Connection Manager failed. Reason: {}".format(conn_id, str(err))
            self.logger.fatal(message)
            raise Exception(message)

        if response.status_code == 200:
            try:
                connection_detail = response.json()["contentData"]
                scheme = "https" if connection_detail['protocol'] == 'swebhdfs' else "http"
                internal_url = "{scheme}://{host}:{port}".format(
                    scheme=scheme,
                    host=connection_detail['host'],
                    port=connection_detail['port']
                )
                external_url = "{scheme}://{host}:{port}".format(
                    scheme=scheme,
                    host=connection_detail['publicHost'],
                    port=connection_detail['publicPort']
                )
                token = connection_detail['authToken']

                conn = DATA_LAKE_CONNECTION(internal_url=internal_url, external_url=external_url, token=token)
                return conn

            except KeyError as e:
                message = "Failed to get Data Lake connection details from connection manager. {}".format(str(e))
                raise Exception(message)
        else:
            error = get_error_message_from_http_response(response)
            message = u"Retrieving connection details for Data Lake failed with code {}. Error message: {}".format(
                response.status_code, error
            )
            raise Exception(message)

    def _prepare_training_artifacts(self, artifact_for_scripts: TRAINING_SCRIPT_ARTIFACT):
        artifacts = []

        # Input artifacts
        for in_artifact in self.config.artifacts:
            name = in_artifact['name']
            artifact = self._get_artifact_by_id(artifact_id=in_artifact['artifactId'])
            # Parse uri to get the Data Lake connection id and the path of the artifact in Data Lake
            connection_id, path = self._parse_artifact_uri(artifact['uri'])
            dl_conn = self._get_data_lake_connection_details(connection_id)
            uri = "{}/webhdfs/v1/{}".format(dl_conn.external_url, path.lstrip('/'))
            artifacts.append(create_artifact_spec(name=name, type='IN', uri=uri, token=dl_conn.token))

        # All output aritfacts will be put in the sap data lake
        dl_conn = self._get_data_lake_connection_details(self.sap_dl_connection_id)
        for artifact in self.artifact_outports:
            uri = create_dl_artifact_uri(
                dl_url=dl_conn.external_url,
                execution_id=self._graph_handle,
                op_id=self.operator_id,
                artifact_name=artifact
            )
            artifacts.append(create_artifact_spec(name=artifact, type='OUT', uri=uri, token=dl_conn.token))

        # Add the special artifact that represents the training script
        script_uri = "{}/webhdfs/v1/{}".format(dl_conn.external_url, artifact_for_scripts.path_in_dl.lstrip('/'))
        name = artifact_for_scripts.name
        artifacts.append(create_artifact_spec(name=name, type="IN", uri=script_uri, token=dl_conn.token))

        return artifacts

    def _get_data_lake_client(self) -> (DATA_LAKE_CONNECTION, InsecureClient):
        """
        Create an HDFS client for accessing Data Lake
        """
        dl_conn = self._get_data_lake_connection_details(self.sap_dl_connection_id)

        session = requests.session()
        session.headers = {'Authorization': 'Bearer {}'.format(dl_conn.token)}
        session.verify = self.ca_cert
        client = InsecureClient(url=dl_conn.internal_url, user=self.sap_dl_user, session=session)
        return dl_conn, client

    def _register_all_dl_output_artifacts(self):
        dl_conn, dl_client = self._get_data_lake_client()

        registered_artifacts = dict()
        for name in self.artifact_outports:
            artifact_id = self._register_dl_artifact(
                artifact_name=name,
                external_dl_url=dl_conn.external_url,
                dl_client=dl_client
            )
            if artifact_id:
                registered_artifacts[name] = artifact_id

        return registered_artifacts

    def _register_dl_artifact(self, artifact_name, external_dl_url: str, dl_client: InsecureClient):
        """
        Register an output artifact in data lake with ML API
        """
        # Read the artifact manifest file from data lake
        manifest = None
        try:
            manifest = read_artifact_manifest(
                exec_id=self._graph_handle,
                op_id=self.operator_id,
                artifact_name=artifact_name,
                dl_client=dl_client
            )
        except HdfsError as e:
            if str(e).startswith("No such file or directory"):
                message = "Cannot find manifest file for artifact \"{}\", ignoring the artifact.".format(artifact_name)
                self.logger.warning(message)
            else:
                message = "Failed to read manifest file for artifact \"{}\". Reason: {}".format(artifact_name, str(e))
                self.logger.fatal(message)
                raise Exception(message)
        except requests.exceptions.RequestException as e:
            message = "Failed to connect Data Lake to read the manifest file for artifact {}. Reason: {}.".format(
                artifact_name, str(e)
            )
            self.logger.fatal(message)
            raise Exception(message)

        if manifest:
            # encode artifact uri with connection id
            raw_uri = manifest.get('uri')
            dl_prefix = "{}/webhdfs/v1/".format(external_dl_url)
            path_within_dl = raw_uri[len(dl_prefix):]
            encoded_uri = "dh-dl://{}/{}".format(self.sap_dl_connection_id, path_within_dl.lstrip('/'))

            # Register the output artifact with ML API
            artifact_id = self._register_artifact(
                artifact_name=manifest.get('name'),
                artifact_kind=manifest.get('kind', 'other'),
                execution_id=self._graph_handle,
                uri=encoded_uri,
                description=manifest.get('description')
            )
            return artifact_id

    def _get_minio_client(self):
        """
        Initialize minio_client with an endpoint and access/secret keys
        """
        if not (self.access_key and self.secret_key and self.endpoint):
            headers = self._prepare_header_for_mlf_request()
            storage_endpoint = u"{}/api/v2/storage".format(self.mlf_training_api_url)

            try:
                response = requests.get(storage_endpoint, headers=headers)
            except requests.exceptions.RequestException as err:
                message = "GET request to MLF storage endpoint failed. Reason: {}".format(str(err))
                self.logger.fatal(message)
                raise Exception(message)

            if response.status_code == 200:
                r = response.json()
                self.access_key = r[u'accessKey']
                self.secret_key = r[u'secretKey']
                self.endpoint = r[u'endpoint']
            else:
                error = get_error_message_from_http_response(response)
                message = u"Retrieving MLF storage details failed with code {}. Error message: {}".format(
                    response.status_code, error
                )
                raise Exception(message)

        # Initialize minio_client with an endpoint and access/secret keys.
        minio_client = Minio(self.endpoint,
                             access_key=self.access_key,
                             secret_key=self.secret_key,
                             secure=True)
        return minio_client

    def _upload_training_scripts(self) -> TRAINING_SCRIPT_ARTIFACT:
        """
        Upload training scripts to Data Lake
        """
        self.logger.info(u"Uploading training scripts of job %s", self.jobID)
        self.dl_dir_for_scripts = "/shared/sap/di/ml/executions/{}/{}".format(self._graph_handle, self.operator_id)

        dl_conn, dl_client = self._get_data_lake_client()
        artifact_name_for_scripts = "script{}".format(uuid.UUID(self.jobID).hex)
        script_dir_in_job_container = '/artifact/input/{}'.format(artifact_name_for_scripts)

        try:
            # Create a directory for the training scripts in Data Lake
            dl_client.makedirs(self.dl_dir_for_scripts)

            if self.config.scripts_folder:
                dl_client.upload(
                    hdfs_path=self.dl_dir_for_scripts,
                    local_path=str(self.config.scripts_folder),
                    overwrite=True,
                    n_threads=5
                )
                script_path_in_data_lake = Path(self.dl_dir_for_scripts, self.config.scripts_folder.name)
                script_path_in_job_container = Path(script_dir_in_job_container, self.config.scripts_folder.name,
                                                    self.config.script)
            else:
                script_file_name = "model.py"
                script_path_in_data_lake = Path(self.dl_dir_for_scripts, script_file_name)
                with dl_client.write(hdfs_path=str(script_path_in_data_lake), encoding='utf-8') as f:
                    f.write(self.config.script)
                script_path_in_job_container = Path(script_dir_in_job_container, script_file_name)

            artifact_for_training_script = TRAINING_SCRIPT_ARTIFACT(
                name=artifact_name_for_scripts,
                path_in_dl=str(script_path_in_data_lake),
                path_in_job_container=str(script_path_in_job_container)
            )
        except HdfsError as e:
            raise Exception("Failed to upload training scripts to Data Lake. Reason: {}".format(str(e)))

        self._train(artifact_for_training_script)

    def _prepare_header_for_mlf_request(self):
        header = {'Authorization': self._get_mlf_token().get_bearer()}
        return header

    def _prestart(self):
        self._get_mlf_connection_details()
        self._get_mlf_token()
        self.jobID = str(uuid.uuid4())
        self.mlf_training_job_endpoint = "{}/api/v3alpha/jobs/{}".format(self.mlf_training_api_url, self.jobID)
        if not self.artifact_inports:
            self._upload_training_scripts()

    def shutdown(self):
        """
        Delete training job on shutdown
        """
        self._delete_training_job(is_poll_for_deletion=False)
        job_status = None
        for i in range(5):
            job_status = self._is_deletion_complete()
            if job_status == 404:
                break
            time.sleep(5)

        if job_status != 404:
            message = "Deletion of training job {} was unsuccessful. Last status of job : {}".format(
                self.jobID, job_status
            )
            self.logger.warning(message)
